
const puppeteer = require("puppeteer");

const DOMAIN = process.env.DOMAIN || 'example.localhost';
const PORT = process.env.PORT || 1337;
const SITE = process.env.SITE || `http://${DOMAIN}:${PORT}`;

const FLAG = process.env.FLAG || "flag{fake_flag}";
const FLAG_REGEX = /^flag{.+}$/;

const sleep = async (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const visit = (url) => {
    return new Promise(async (resolve, reject) => {
        if (!FLAG_REGEX.test(FLAG)) {
            return reject(new Error("Error: Flag does not match flag regex, contact the author if this is on remote"));
        }

        let browser, page, context;
        try {
            browser = await puppeteer.launch({
                headless: true,
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-gpu',
                    '--no-first-run',
                    '--disable-default-apps',
                    '--disable-extensions'
                ],
                dumpio: true,
                pipe: true,
                executablePath: process.env.PUPPETEER_EXECUTABLE_PATH
            });

            context = await browser.createBrowserContext();

            page = await context.newPage();

            console.log(`The admin will visit ${SITE} first, and then ${url}`);

            await page.goto(`${SITE}`, { waitUntil: "domcontentloaded", timeout: 5000 });
            await sleep(100);

            await page.evaluate((flag) => {
                localStorage.setItem('flag', flag);
            }, FLAG);

            console.log(`localStorage.setItem('flag', '${FLAG}')`)

            await sleep(500);
            await page.close();

        } catch (err) {
            console.error(err);
            if (browser) await browser.close();
            return reject(new Error("Error: Setup failed, if this happens consistently on remote contact the admin"));
        }

        resolve("The admin will visit your URL soon");

        try {
            page = await context.newPage();

            await page.goto(url, { waitUntil: "domcontentloaded", timeout: 5000 });
            await sleep(120_000);
        } catch (err) {
            console.error(err);
        }

        if (browser) await browser.close();
    });
};

module.exports = { visit };
