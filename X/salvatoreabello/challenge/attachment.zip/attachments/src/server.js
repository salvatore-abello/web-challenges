const express = require('express');
const path = require('path');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { visit } = require('./bot');

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 1337;
const DOMAIN = process.env.DOMAIN || "example.localhost";

app.use((req, res, next) => {
    const nonce = crypto.randomBytes(16).toString('base64');
    res.locals.nonce = nonce;

    res.setHeader("Content-Security-Policy", `default-src 'none'; script-src 'nonce-${nonce}'; connect-src *.${DOMAIN}:${PORT}; base-uri 'none'; frame-ancestors 'none'`);
    next();
});

const reportLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 1,
  message: {
    error: 'Rate limit exceeded',
    message: 'Too many URL reports'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.post('/report', reportLimiter, async (req, res) => {
  const { url } = req.body;
  
  if (!url) {
    return res.status(400).json({ error: 'Bad request' });
  }
  
  try {
    const urlObj = new URL(url);
    if (!['http:', 'https:'].includes(urlObj.protocol)) {
      return res.status(400).json({ error: 'Bad request' });
    }
  } catch (e) {
    return res.status(400).json({ error: 'Invalid URL' });
  }
  
  try {
    const result = await visit(url);
    
    res.json({ 
      success: true, 
      message: 'URL reported successfully. The admin will visit it soon.',
      details: result
    });
  } catch (error) {
    console.error('Error visiting URL:', error);
    res.status(500).json({ 
      error: 'Failed to process URL report',
      message: error.message 
    });
  }
});

app.get('/', (req, res) => {
    res.render('index', {DOMAIN, PORT});
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
