import { useState } from 'react';
import SpaceBackground from './components/SpaceBackground';
import Header from './components/Header';
import ClassificationForm from './components/ClassificationForm';
import ResultsPanel from './components/ResultsPanel';

function App() {
  const [result, setResult] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [showResults, setShowResults] = useState(false);

  const handleClassificationResult = (url, data) => {
    setImageUrl(url);
    setResult(data);
    setShowResults(true);
  };

  return (
    <>
      <SpaceBackground />
      
      <div className="page-shell">
        <Header />
        
        <main className="main-grid">
          <section className="hero-panel glass-card">
            <h2>Classify any space image in seconds.</h2>
            <p className="hero-text">
              Paste a public image URL of a star, planet, or deep-sky object and we'll run it through our classifier.
            </p>

            <ClassificationForm onResult={handleClassificationResult} />
          </section>

          {showResults && (
            <ResultsPanel 
              imageUrl={imageUrl}
              result={result}
            />
          )}
        </main>

      </div>
    </>
  );
}

export default App;
