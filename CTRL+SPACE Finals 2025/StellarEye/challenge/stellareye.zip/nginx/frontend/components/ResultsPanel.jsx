import { useState, useEffect } from 'react';

const iconSVG = {
  'star': `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2 L14.4 9.2 L22 9.2 L15.8 14.4 L18.4 22 L12 16.8 L5.6 22 L8.2 14.4 L2 9.2 L9.6 9.2 Z" fill="#ffd700"/>
  </svg>`,
  'planet': `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="8" fill="#4a7fff"/>
    <ellipse cx="12" cy="12" rx="11" ry="3" fill="none" stroke="#4a7fff" stroke-width="1.5" opacity="0.6"/>
  </svg>`,
  'other': `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="12" cy="12" rx="10" ry="6" fill="none" stroke="#b47fff" stroke-width="1.5" transform="rotate(-30 12 12)"/>
    <circle cx="12" cy="12" r="3" fill="#b47fff"/>
    <circle cx="6" cy="8" r="1" fill="#b47fff" opacity="0.6"/>
    <circle cx="18" cy="16" r="1" fill="#b47fff" opacity="0.6"/>
    <circle cx="16" cy="7" r="0.5" fill="#b47fff" opacity="0.4"/>
  </svg>`
};

function ResultsPanel({ imageUrl, result }) {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    setTimeout(() => setAnimated(true), 50);
  }, []);

  const classificationRaw = result.classification || result.label || result.prediction || 'other';
  const classification = String(classificationRaw).toLowerCase();
  
  const probs = result.probabilities || result.probs || result.scores || {};
  const conf = typeof result.confidence === 'number'
    ? result.confidence
    : (typeof probs[classification] === 'number' ? probs[classification] : 0);

  const badgeColors = {
    'star': 'rgba(255, 215, 0, 0.1)',
    'planet': 'rgba(74, 127, 255, 0.1)',
    'other': 'rgba(180, 127, 255, 0.1)'
  };

  const borderColors = {
    'star': 'rgba(255, 215, 0, 0.3)',
    'planet': 'rgba(74, 127, 255, 0.3)',
    'other': 'rgba(180, 127, 255, 0.3)'
  };

  const ProbabilityBar = ({ type, value }) => {
    const [width, setWidth] = useState(0);
    
    useEffect(() => {
      setTimeout(() => setWidth(value * 100), 50);
    }, [value]);

    const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);

    return (
      <div className="prob-item">
        <div className="prob-top">
          <span>{capitalize(type)}</span>
          <span>{(value * 100).toFixed(1)}%</span>
        </div>
        <div className="prob-bar">
          <div 
            className={`prob-fill prob-${type}`}
            style={{ width: `${width}%` }}
          ></div>
        </div>
      </div>
    );
  };

  return (
    <section className={`results-panel glass-card ${animated ? 'show-results' : ''}`}>
      <h3>Prediction</h3>
      <div className="main-result">
        <div 
          className="result-badge"
          style={{
            background: badgeColors[classification] || badgeColors['other'],
            borderColor: borderColors[classification] || borderColors['other']
          }}
        >
          <span 
            className="badge-icon"
            dangerouslySetInnerHTML={{ __html: iconSVG[classification] || iconSVG['other'] }}
          />
          <span className="badge-text">{classificationRaw || 'Unknown'}</span>
        </div>
        <div className="confidence-line">
          <span className="label">Confidence</span>
          <span className="value">{(conf * 100).toFixed(1)}%</span>
        </div>
      </div>

      <div className="probabilities">
        <h4>All probabilities</h4>
        <ProbabilityBar type="star" value={probs.star ?? 0} />
        <ProbabilityBar type="planet" value={probs.planet ?? 0} />
        <ProbabilityBar type="other" value={probs.other ?? 0} />
      </div>
    </section>
  );
}

export default ResultsPanel;
