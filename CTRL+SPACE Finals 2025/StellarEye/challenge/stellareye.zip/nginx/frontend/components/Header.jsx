function Header() {
  return (
    <header className="site-header">
      <div className="logo-group">
        <span className="logo-mark">🌌</span>
        <div className="logo-text">
          <h1>StellarEye</h1>
          <p>Python powered space image classification</p>
        </div>
      </div>

    </header>
  );
}

export default Header;
