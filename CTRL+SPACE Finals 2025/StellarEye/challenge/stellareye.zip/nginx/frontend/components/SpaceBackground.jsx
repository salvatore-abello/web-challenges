import { useEffect, useRef } from 'react';
import * as THREE from 'three';

function SpaceBackground() {
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const scene = new THREE.Scene();

    const camera = new THREE.PerspectiveCamera(
      55,
      window.innerWidth / window.innerHeight,
      0.1,
      2000
    );
    camera.position.set(0, 10, 28);

    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // Pure black background
    const gradientTexture = new THREE.CanvasTexture(createGradient());
    scene.background = gradientTexture;

    function createGradient() {
      const c = document.createElement('canvas');
      c.width = 2;
      c.height = 512;
      const ctx = c.getContext('2d');
      const g = ctx.createLinearGradient(0, 0, 0, 512);
      g.addColorStop(0, '#000000');
      g.addColorStop(0.5, '#000000');
      g.addColorStop(1, '#000000');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, 2, 512);
      return c;
    }

    const starGeometry = new THREE.BufferGeometry();
    const starCount = 12000;
    const starPositions = new Float32Array(starCount * 3);
    const starSizes = new Float32Array(starCount);
    const starColors = new Float32Array(starCount * 3);

    for (let i = 0; i < starCount; i++) {
      const i3 = i * 3;
      starPositions[i3] = (Math.random() - 0.5) * 600;
      starPositions[i3 + 1] = (Math.random() - 0.5) * 300;
      starPositions[i3 + 2] = (Math.random() - 0.5) * 600;

      starSizes[i] = Math.random() * 2.5 + 1.0;

      const colorChoice = Math.random();
      if (colorChoice < 0.3) {
        starColors[i3] = 1.0;
        starColors[i3 + 1] = 1.0;
        starColors[i3 + 2] = 1.0;
      } else if (colorChoice < 0.6) {
        starColors[i3] = 0.9;
        starColors[i3 + 1] = 0.95;
        starColors[i3 + 2] = 1.0;
      } else {
        starColors[i3] = 1.0;
        starColors[i3 + 1] = 0.96;
        starColors[i3 + 2] = 0.85;
      }
    }

    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('size', new THREE.BufferAttribute(starSizes, 1));
    starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));

    const starMaterial = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0.0 }
      },
      vertexShader: `
        attribute float size;
        varying vec3 vColor;
        uniform float time;

        void main() {
          vColor = color;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          float twinkle1 = sin(time * 0.7 + position.x * 0.35 + position.y * 0.2) * 0.35 + 0.65;
          float twinkle2 = sin(time * 1.1 + position.z * 0.25) * 0.25 + 0.75;
          float twinkle = clamp(twinkle1 * twinkle2, 0.55, 1.25);
          float pointSize = size * (400.0 / max(-mvPosition.z, 1.0)) * twinkle;
          pointSize = clamp(pointSize, 1.5, 12.0);
          gl_PointSize = pointSize;
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        void main() {
          float d = distance(gl_PointCoord, vec2(0.5));
          if (d > 0.5) discard;
          float falloff = pow(1.0 - d * 2.0, 1.8);
          gl_FragColor = vec4(vColor * 1.2 * falloff, falloff);
        }
      `,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      transparent: true,
      vertexColors: true
    });

    const stars = new THREE.Points(starGeometry, starMaterial);
    scene.add(stars);

    let time = 0;
    let animationId;

    function animate() {
      animationId = requestAnimationFrame(animate);
      time += 0.008;

      starMaterial.uniforms.time.value = time;
      stars.rotation.y += 0.00015;
      stars.rotation.x = Math.sin(time * 0.08) * 0.02;

      renderer.render(scene, camera);
    }

    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationId);
      renderer.dispose();
      starGeometry.dispose();
      starMaterial.dispose();
    };
  }, []);

  return <canvas ref={canvasRef} id="space-canvas" />;
}

export default SpaceBackground;
