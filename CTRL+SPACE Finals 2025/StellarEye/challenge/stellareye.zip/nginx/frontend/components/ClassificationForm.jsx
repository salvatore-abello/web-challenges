import { useState, useEffect } from 'react';

const API_URL = '/api';

function ClassificationForm({ onResult }) {
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [placeholder, setPlaceholder] = useState('https://images.nasa.gov/...');

  const placeholderTexts = [
    'https://images.nasa.gov/...',
    'https://hubblesite.org/...',
    'https://apod.nasa.gov/...',
    'https://www.eso.org/...'
  ];

  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      currentIndex = (currentIndex + 1) % placeholderTexts.length;
      setPlaceholder(placeholderTexts[currentIndex]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!imageUrl.trim()) return;

    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/classify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: imageUrl,
          params: {}
        })
      });

      if (!response.ok) {
        let message = 'Classification failed';
        try {
          const err = await response.json();
          message = err.detail || err.message || message;
        } catch (_) {
          const text = await response.text();
          if (text) message = text;
        }
        throw new Error(message);
      }

      const result = await response.json();
      onResult(imageUrl, result);
    } catch (error) {
      setError(error.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="search-form">
        <label htmlFor="imageUrl" className="input-label">Image URL</label>
        <div className="input-row">
          <input 
            type="url"
            id="imageUrl"
            placeholder={placeholder}
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            required
            autoComplete="off"
          />
          <button type="submit" id="searchBtn" disabled={loading}>
            <span className="btn-text" style={{ display: loading ? 'none' : 'inline-flex' }}>
              Classify
            </span>
            <span className="btn-loading" style={{ display: loading ? 'inline-flex' : 'none' }}>
              <span className="spinner"></span>
              Analyzing...
            </span>
          </button>
        </div>
      </form>

      {error && (
        <div className="alert error">
          {error}
        </div>
      )}
    </>
  );
}

export default ClassificationForm;
