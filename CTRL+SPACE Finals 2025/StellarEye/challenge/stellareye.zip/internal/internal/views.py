from selenium import webdriver
from django.http import HttpResponse, JsonResponse
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait

from selenium.common.exceptions import (
    TimeoutException,
    InvalidArgumentException,
    JavascriptException,
    SessionNotCreatedException,
    InvalidSessionIdException,
    InsecureCertificateException
)

def handle_request(request):
    driver = None
    
    try:
        url = request.GET.get('url')
        if not url:
            return HttpResponse("Missing 'url' parameter", status=400)
        
        if not url.startswith("http"):
            return HttpResponse("Invalid url", status=400)

        chrome_options = Options()
        
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        
        driver = webdriver.Chrome(options=chrome_options)
        driver.get(url)

        WebDriverWait(driver, 5).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        
        return JsonResponse({"status": "OK", "reason": ""}, status=200)
        
    except TimeoutException:
        return JsonResponse({"status": "NOT OK", "reason": "Timeout"})
    except InvalidArgumentException:
        return JsonResponse({"status": "NOT OK", "reason": "Invalid argument exception"})
    except JavascriptException:
        return JsonResponse({"status": "NOT OK", "reason": "JavaScript execution failed in the browser"})
    except SessionNotCreatedException:
        return JsonResponse({"status": "NOT OK", "reason": "WebDriver session could not be created"})
    except InvalidSessionIdException:
        return JsonResponse({"status": "NOT OK", "reason": "Session ID is invalid or session has expired"})
    except InsecureCertificateException:
        return JsonResponse({"status": "NOT OK", "reason": "Navigation failed due to insecure/invalid certificate"})
    finally:
        if driver:
            driver.quit()
