import os
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response

from models import ImageRequest, PredictionResponse
from auth import verify_token
from utils import download_image, classify_image

router = APIRouter()


@router.get("/")
async def root():
    return {"message": "Welcome to StellarEye API"}


@router.get("/health")
async def health_check():
    return {"status": "healthy"}


@router.get("/download/{filename:path}")
async def download_static_image(filename: str, token: str = Depends(verify_token)):
    filename = filename.replace("..", "")

    filepath = os.path.join("/app/images", filename)

    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="File not found")

    if not os.path.isfile(filepath):
        raise HTTPException(status_code=400, detail="Path is not a file")

    try:
        with open(filepath, "rb") as f:
            file_data = f.read()

        return Response(
            content=file_data,
            media_type="application/octet-stream",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read file: {str(e)}")


@router.post("/classify", response_model=PredictionResponse)
async def classify_celestial_object(image_data: ImageRequest):
    try:
        image = download_image(image_data.url)
        result = classify_image(image)

        return PredictionResponse(
            classification=result["classification"],
            confidence=result["confidence"],
            probabilities=result["probabilities"],
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Classification failed: {str(e)}")
