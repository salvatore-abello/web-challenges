import os
from fastapi import HTTPException, Header
import base64


DOWNLOAD_CREDS = os.environ.get("DOWNLOAD_CREDS", os.urandom(32).hex())

def verify_token(authorization: str = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header missing")

    try:
        scheme, token = authorization.split(" ", 1)
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Invalid authorization scheme")

        try:
            print("token", token, flush=True)
            decoded_token = base64.b64decode(token).decode()
        except Exception:
            raise HTTPException(status_code=401, detail="Invalid token encoding")

        print("token2", decoded_token, DOWNLOAD_CREDS, flush=True)

        if decoded_token != DOWNLOAD_CREDS:
            raise HTTPException(status_code=401, detail="Invalid token")

        return decoded_token
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid authorization format")
