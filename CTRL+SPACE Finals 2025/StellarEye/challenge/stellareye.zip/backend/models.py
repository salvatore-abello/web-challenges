from pydantic import BaseModel
from typing import Dict, Any


class ImageRequest(BaseModel):
    url: str
    params: Dict[str, Any] = {}

class PredictionResponse(BaseModel):
    classification: str
    confidence: float
    probabilities: dict[str, float]
