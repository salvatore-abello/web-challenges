import os
import socket
import random
import ipaddress
from io import BytesIO
from urllib.parse import urlparse, urlunparse

import requests
from PIL import Image, ImageFile
from requests_toolbelt.adapters.host_header_ssl import HostHeaderSSLAdapter

ImageFile.LOAD_TRUNCATED_IMAGES = True

ALLOWED_SCHEMES = {"http", "https"}
ALLOWED_PORTS = {80, 443}
MAX_BYTES = 10 * 1024 * 1024


def is_safe_ip(ip_str: str) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
        return ip.is_global
    except ValueError:
        return False


def _default_port(parsed) -> int:
    if parsed.port:
        return parsed.port
    return 443 if parsed.scheme == "https" else 80


def _resolve_public_ip(hostname: str, port: int) -> str:
    infos = socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
    for family, _, _, _, sockaddr in infos:
        ip = sockaddr[0]
        if is_safe_ip(ip):
            return ip
    raise ValueError(f"No allowed public IP for {hostname}")


def _build_ip_url(parsed, ip: str) -> str:
    userinfo = ""
    if parsed.username:
        userinfo = parsed.username
        if parsed.password:
            userinfo += f":{parsed.password}"
        userinfo += "@"

    host = f"[{ip}]" if ":" in ip else ip

    port = f":{parsed.port}" if parsed.port else ""

    new_netloc = f"{userinfo}{host}{port}"
    return urlunparse(parsed._replace(netloc=new_netloc))


def classify_image(image: Image.Image):
    classes = ["star", "planet", "other"]

    probs = [random.random() for _ in range(3)]
    total = sum(probs)
    probs = [p / total for p in probs]

    max_idx = probs.index(max(probs))
    predicted_class = classes[max_idx]

    return {
        "classification": predicted_class,
        "confidence": probs[max_idx],
        "probabilities": {"star": probs[0], "planet": probs[1], "other": probs[2]},
    }


def download_image(url: str) -> Image.Image:
    parsed = urlparse(url)

    if parsed.scheme not in ALLOWED_SCHEMES:
        raise ValueError("Only http/https URLs are allowed")

    if not parsed.hostname:
        raise ValueError("Invalid URL: no hostname found")

    port = _default_port(parsed)
    if port not in ALLOWED_PORTS:
        raise ValueError(f"Port {port} is not allowed")

    hostname = parsed.hostname

    socket.setdefaulttimeout(5.0)
    try:
        ip = _resolve_public_ip(hostname, port)
    finally:
        socket.setdefaulttimeout(None)

    ip_url = _build_ip_url(parsed, ip)
    headers = {
        "User-Agent": "StellarEye/1.0.0",
        "Accept": "image/*",
        "Host": hostname,
    }

    session = requests.Session()
    session.trust_env = False
    session.proxies = {}
    session.mount("https://", HostHeaderSSLAdapter())

    with session.get(ip_url, headers=headers, allow_redirects=False, stream=True) as resp:
        if 300 <= resp.status_code < 400:
            raise ValueError(f"Redirects are not allowed (status {resp.status_code})")

        resp.raise_for_status()

        content_type = resp.headers.get("content-type", "")
        if not content_type.lower().startswith("image/"):
            raise ValueError(f"URL does not point to an image. Content-Type: {content_type}")

        data = BytesIO()
        total = 0
        for chunk in resp.iter_content(chunk_size=64 * 1024):
            if not chunk:
                continue
            total += len(chunk)
            if total > MAX_BYTES:
                raise ValueError(f"Image larger than {MAX_BYTES} bytes")
            data.write(chunk)
        data.seek(0)

    try:
        img = Image.open(data)
        img.verify()
        data.seek(0)
        img = Image.open(data).copy()
    except Exception as e:
        raise ValueError(f"Invalid or corrupted image: {e}")

    os.makedirs("/app/images", exist_ok=True)
    filename = os.path.basename(parsed.path) or f"image_{random.randint(1000, 9999)}"

    lower = filename.lower()
    if not lower.endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp")):
        ext = content_type.split("/")[-1].split(";")[0].lower()
        if ext not in ("png", "jpg", "jpeg", "gif", "bmp", "webp"):
            ext = "jpg"
        filename += f".{ext}"

    filepath = os.path.join("/app/images", filename)
    img.save(filepath)

    return img
