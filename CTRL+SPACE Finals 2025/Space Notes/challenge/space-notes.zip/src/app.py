import secrets
from flask import Flask, render_template, session, g
from flask_wtf.csrf import CSRFProtect
from config import SECRET_KEY, WTF_CSRF_ENABLED, WTF_CSRF_TIME_LIMIT
from database import close_connection, init_db
from auth import login_required
from werkzeug.middleware.proxy_fix import ProxyFix

from routes.auth import auth_bp
from routes.posts import posts_bp
from routes.api import api_bp


def create_app():
    app = Flask(__name__)
    app.secret_key = SECRET_KEY
    app.config['WTF_CSRF_ENABLED'] = WTF_CSRF_ENABLED
    app.config['WTF_CSRF_TIME_LIMIT'] = WTF_CSRF_TIME_LIMIT
    app.config["WTF_CSRF_SSL_STRICT"] = False

    app.wsgi_app = ProxyFix(
        app.wsgi_app,
        x_for=1,
        x_proto=1,
        x_host=1,
        x_port=1,
        x_prefix=1,
    )

    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    
    CSRFProtect(app)
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(posts_bp)
    app.register_blueprint(api_bp)
    
    app.teardown_appcontext(close_connection)
    
    init_db(app)
    
    @app.before_request
    def generate_nonce():
        g.nonce = secrets.token_urlsafe(16)
    
    @app.after_request
    def add_security_headers(response):
        nonce = getattr(g, 'nonce', '')
        response.headers['Content-Security-Policy'] = (
            f"default-src 'none'; "
            f"script-src 'self' 'nonce-{nonce}' "
            f"https://cdn.jsdelivr.net/npm/marked/marked.min.js "
            f"https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js "
            f"https://js.hcaptcha.com/1/api.js "
            f"https://hcaptcha.com/1/api.js; "
            f"style-src 'self' https://fonts.googleapis.com; "
            f"font-src https://fonts.gstatic.com; "
            f"frame-src https://hcaptcha.com https://*.hcaptcha.com; "
            f"connect-src 'self' https://hcaptcha.com https://*.hcaptcha.com; "
            f"base-uri 'none'; "
            f"form-action 'self'; "
            f"frame-ancestors 'none'"
        )

        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer" 
        response.headers["Document-Policy"] = "force-load-at-top"
        response.headers["Cache-Control"] = "no-store"
        return response
    
    @app.route('/')
    @login_required
    def index():
        return render_template('index.html', username=session.get('username'), nonce=g.nonce)
    
    @app.context_processor
    def inject_csrf_token():
        from flask_wtf.csrf import generate_csrf
        return dict(csrf_token=generate_csrf)
    
    return app


if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=80)
