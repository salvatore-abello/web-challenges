import hashlib
import hmac
import time
import secrets
import requests
from config import HCAPTCHA_SECRET_KEY, HCAPTCHA_VERIFY_URL, POW_DIFFICULTY, POW_EXPIRATION, POW_SECRET


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def verify_hcaptcha(response_token):
    data = {
        'secret': HCAPTCHA_SECRET_KEY,
        'response': response_token
    }
    
    try:
        response = requests.post(HCAPTCHA_VERIFY_URL, data=data)
        result = response.json()
        return result.get('success', False)
    except Exception as e:
        print(f"hCaptcha verification error: {e}")
        return False


def generate_pow_challenge():
    token = secrets.token_urlsafe(32)
    expires = int(time.time()) + POW_EXPIRATION
    
    message = f"{token}.{expires}.{POW_DIFFICULTY}"
    sig = hmac.new(
        POW_SECRET.encode() if isinstance(POW_SECRET, str) else POW_SECRET,
        message.encode(),
        hashlib.sha256
    ).hexdigest()
    
    return {
        'token': token,
        'difficulty': POW_DIFFICULTY,
        'expires': expires,
        'sig': sig
    }


def count_leading_zero_bits(data: bytes) -> int:
    bits = 0
    for byte in data:
        if byte == 0:
            bits += 8
            continue
        
        for i in range(7, -1, -1):
            if (byte & (1 << i)) == 0:
                bits += 1
            else:
                return bits
    return bits


def verify_pow_solution(pow_data):
    try:
        token = pow_data.get('token')
        nonce = pow_data.get('nonce')
        sig = pow_data.get('sig')
        expires = pow_data.get('expires')
        difficulty = pow_data.get('difficulty')
        
        if not all([token, nonce, sig, expires is not None, difficulty is not None]):
            return False, "Missing required PoW fields"
        
        message = f"{token}.{expires}.{difficulty}"
        expected_sig = hmac.new(
            POW_SECRET.encode() if isinstance(POW_SECRET, str) else POW_SECRET,
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        
        if not hmac.compare_digest(sig, expected_sig):
            return False, "Invalid PoW signature"
        
        if int(time.time()) > expires:
            return False, "PoW challenge expired"
        
        if difficulty != POW_DIFFICULTY:
            return False, "Invalid difficulty"
        
        hash_input = f"{token}.{nonce}"
        hash_bytes = hashlib.sha256(hash_input.encode()).digest()
        leading_zeros = count_leading_zero_bits(hash_bytes)
        
        if leading_zeros < difficulty:
            return False, f"Insufficient work: {leading_zeros} < {difficulty}"
        
        return True, "Valid PoW solution"
        
    except Exception as e:
        return False, f"PoW verification error: {str(e)}"
