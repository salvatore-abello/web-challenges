from flask import Blueprint, jsonify, request, session
import requests
from database import get_db
from auth import login_required
from utils import generate_pow_challenge, verify_pow_solution

api_bp = Blueprint('api', __name__)


@api_bp.get("/report/pow")
def get_pow_challenge():
    challenge = generate_pow_challenge()
    return jsonify(challenge)


@api_bp.post("/report")
def report():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid request format"}), 400
    
    url = data.get("url")
    pow_solution = data.get("pow")
    
    if not url:
        return jsonify({"error": "No URL provided"}), 400
    
    if not pow_solution:
        return jsonify({"error": "PoW solution required"}), 400
    
    valid, message = verify_pow_solution(pow_solution)
    if not valid:
        return jsonify({"error": f"Invalid PoW: {message}"}), 403
    
    try:
        requests.post("http://localhost:3000/report", json={"url": url})
        return jsonify({"result": "Report submitted successfully"}), 200
    except Exception as e:
        return jsonify({"error": f"Failed to submit report: {str(e)}"}), 500


@api_bp.get('/api/posts')
@login_required
def get_posts():
    user_id = session.get('user_id')
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT id, title, content, author, user_id, timestamp 
        FROM posts 
        WHERE user_id = ? 
        ORDER BY id DESC
    ''', (user_id,))
    
    posts = []
    for row in cursor.fetchall():
        posts.append({
            'id': row['id'],
            'title': row['title'],
            'content': row['content'],
            'author': row['author'],
            'user_id': row['user_id'],
            'timestamp': row['timestamp']
        })
    
    return jsonify({'posts': posts})


@api_bp.get('/api/post/<int:post_id>')
@login_required
def get_post_data(post_id):
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute('''
        SELECT id, title, content, author, user_id, timestamp 
        FROM posts WHERE id = ?
    ''', (post_id,))
    post_row = cursor.fetchone()
    
    if post_row is None:
        return jsonify({'error': 'Post not found'}), 404
    
    post = dict(post_row)
    
    if post['user_id'] != session.get('user_id'):
        return jsonify({'error': 'Permission denied'}), 403
    
    cursor.execute('''
        SELECT id, text, author, timestamp 
        FROM comments WHERE post_id = ?
        ORDER BY timestamp ASC
    ''', (post_id,))
    post_comments = [dict(row) for row in cursor.fetchall()]
    
    return jsonify({
        'post': post,
        'comments': post_comments
    })
