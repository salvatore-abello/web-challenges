from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g
from datetime import datetime
from database import get_db
from utils import verify_hcaptcha
from auth import login_required
from config import HCAPTCHA_SITE_KEY

posts_bp = Blueprint('posts', __name__)


@posts_bp.get('/search')
@login_required
def search():
    query = request.args.get('query', '')
    user_id = session.get('user_id')
    
    results = []
    if query:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            SELECT id, title, content, author, user_id, timestamp
            FROM posts 
            WHERE user_id = ? AND (
                content LIKE ?
            )
            ORDER BY timestamp DESC
        ''', (user_id, f'%{query}%'))
        results = [dict(row) for row in cursor.fetchall()]
    
    return render_template('search.html', 
                         username=session.get('username'), 
                         query=query,
                         results=results,
                         nonce=g.nonce)


@posts_bp.post('/post/new')
@login_required
def new_post():
    title = request.form.get('title')
    content = request.form.get('content')
    
    if title and content:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO posts (title, content, author, user_id, timestamp)
            VALUES (?, ?, ?, ?, ?)
        ''', (title, content, session.get('username'), session.get('user_id'), 
              datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        db.commit()
        flash('Post created successfully!', 'success')
        return redirect(url_for('index'))
    else:
        flash('Title and content are required!', 'error')

    return render_template("new_post.html", nonce=g.nonce)


@posts_bp.get("/post/new")
@login_required
def new_post_get():
    return render_template('new_post.html', nonce=g.nonce)


@posts_bp.get('/post/<int:post_id>')
@login_required
def view_post(post_id):
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute('SELECT id, user_id FROM posts WHERE id = ?', (post_id,))
    post = cursor.fetchone()
    
    if post is None:
        flash('Post not found!', 'error')
        return redirect(url_for('index'))
    
    if post['user_id'] != session.get('user_id'):
        flash('You do not have permission to view this post!', 'error')
        return redirect(url_for('index'))
    
    return render_template('view_post.html', post_id=post_id, 
                         hcaptcha_site_key=HCAPTCHA_SITE_KEY,
                         nonce=g.nonce)


@posts_bp.post('/post/<int:post_id>/comment')
@login_required
def add_comment(post_id):
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute('SELECT id, user_id FROM posts WHERE id = ?', (post_id,))
    post = cursor.fetchone()
    
    if post is None:
        flash('Post not found!', 'error')
        return redirect(url_for('index'))
    
    if post['user_id'] != session.get('user_id'):
        flash('You do not have permission to comment on this post!', 'error')
        return redirect(url_for('index'))
    
    hcaptcha_response = request.form.get('h-captcha-response')
    if not hcaptcha_response:
        flash('Please complete the CAPTCHA!', 'error')
        return redirect(url_for('posts.view_post', post_id=post_id))
    
    if not verify_hcaptcha(hcaptcha_response):
        flash('CAPTCHA verification failed. Please try again.', 'error')
        return redirect(url_for('posts.view_post', post_id=post_id))
    
    comment_text = request.form.get('comment')
    
    if comment_text:
        cursor.execute('''
            INSERT INTO comments (post_id, text, author, timestamp)
            VALUES (?, ?, ?, ?)
        ''', (post_id, comment_text, session.get('username'), 
              datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        db.commit()
        flash('Comment added successfully!', 'success')
    else:
        flash('Comment cannot be empty!', 'error')
    
    return redirect(url_for('posts.view_post', post_id=post_id))


@posts_bp.post('/post/<int:post_id>/delete')
@login_required
def delete_post(post_id):
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute('SELECT id, user_id FROM posts WHERE id = ?', (post_id,))
    post = cursor.fetchone()
    
    if post is None:
        flash('Post not found!', 'error')
        return redirect(url_for('index'))
    
    if post['user_id'] != session.get('user_id'):
        flash('You do not have permission to delete this post!', 'error')
        return redirect(url_for('index'))
    
    cursor.execute('DELETE FROM comments WHERE post_id = ?', (post_id,))
    cursor.execute('DELETE FROM posts WHERE id = ?', (post_id,))
    db.commit()
    flash('Post deleted successfully!', 'success')
    
    return redirect(url_for('index'))
