from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g
from database import get_db
from utils import hash_password
from auth import login_required

auth_bp = Blueprint('auth', __name__)


@auth_bp.post('/register')
def register():
    if 'user_id' in session:
        return redirect(url_for('index'))
    
    username = request.form.get('username')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    
    if not username or not password:
        flash('Username and password are required!', 'error')
    elif password != confirm_password:
        flash('Passwords do not match!', 'error')
    elif username == password:
        flash("Your username must be different from the password")
    elif len(password) < 4:
        flash('Password must be at least 4 characters long!', 'error')
    else:
        db = get_db()
        cursor = db.cursor()
        
        cursor.execute('SELECT id FROM users WHERE username = ?', (username,))
        if cursor.fetchone():
            flash('Username already exists!', 'error')
        else:
            cursor.execute('''
                INSERT INTO users (username, password) 
                VALUES (?, ?)
            ''', (username, hash_password(password)))
            db.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('auth.login'))

    return render_template('register.html', nonce=g.nonce)


@auth_bp.get('/register')
def register_get():
    return render_template("register.html", nonce=g.nonce)


@auth_bp.post('/login')
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))

    username = request.form.get('username')
    password = request.form.get('password')
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT id, password FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    
    if user and user['password'] == hash_password(password):
        session['user_id'] = user['id']
        session['username'] = username
        flash('Login successful!', 'success')
        return redirect(url_for('index'))
    else:
        flash('Invalid username or password!', 'error')

    return render_template("login.html", nonce=g.nonce)


@auth_bp.get("/login")
def login_get():
    return render_template('login.html', nonce=g.nonce)


@auth_bp.get('/logout')
@login_required
def logout():
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('auth.login'))
