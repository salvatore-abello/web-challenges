import os

SECRET_KEY = os.environ.get("SECRET_KEY", os.urandom(32))
DATABASE = 'space_notes.db'

WTF_CSRF_ENABLED = True
WTF_CSRF_TIME_LIMIT = None

HCAPTCHA_SITE_KEY = os.environ.get('HCAPTCHA_SITE_KEY', 'changeme')
HCAPTCHA_SECRET_KEY = os.environ.get('HCAPTCHA_SECRET_KEY', 'changeme')
HCAPTCHA_VERIFY_URL = 'https://hcaptcha.com/siteverify'

POW_DIFFICULTY = int(os.environ.get('POW_DIFFICULTY', '20'))
POW_EXPIRATION = int(os.environ.get('POW_EXPIRATION', '300'))
POW_SECRET = os.environ.get('POW_SECRET', os.urandom(32).hex())
