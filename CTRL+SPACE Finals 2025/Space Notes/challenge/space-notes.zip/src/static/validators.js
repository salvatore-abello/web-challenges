
function checkForm(validationRules = {}) {
    for (const [attribute, regex] of Object.entries(validationRules)) {
        const element = document.querySelector(`[name="${attribute}"]`) || document.getElementById(attribute);
        
        if (!element) {
            console.error(`Element with attribute "${attribute}" not found`);
            return false;
        }
        
        const value = element.value;
        
        if (!regex.test(value)) {
            console.error(`Error! "${attribute}" must match the regex ${regex}`);
            return false;
        }
    }
    
    document.forms[0].submit();
    return true;
}
