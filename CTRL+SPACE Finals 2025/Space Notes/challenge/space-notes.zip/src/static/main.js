
async function loadPosts() {
    try {
        marked.setOptions({
            breaks: true,
            gfm: true
        });
        
        const response = await fetch('/api/posts');
        const data = await response.json();
        const postsContainer = document.getElementById('posts-container');
        
        if (data.posts && data.posts.length > 0) {
            postsContainer.innerHTML = '';
            data.posts.forEach(post => {
                const postDiv = document.createElement('div');
                postDiv.className = 'post-card';
                
                const contentHTML = marked.parse(post.content);
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = contentHTML;
                const plainText = tempDiv.textContent || tempDiv.innerText || '';
                const contentPreview = plainText.length > 150 ? 
                    plainText.substring(0, 150) + '...' : plainText;
                
                postDiv.innerHTML = `
                    <h3 class="post-card-title">
                        <a href="/post/${post.id}">
                            ${post.title}
                        </a>
                    </h3>
                    <div class="post-card-preview">${contentPreview}</div>
                    <div class="post-card-footer">
                        <small class="post-card-meta">
                            Posted by ${post.author} on ${post.timestamp}
                        </small>
                        <div class="post-card-actions">
                            <a href="/post/${post.id}" class="btn">View</a>
                            <form method="POST" action="/post/${post.id}/delete">
                                <input type="hidden" name="csrf_token" value="${window.csrfToken || ''}">
                                <button type="submit" class="btn-danger" onclick="return confirm('Are you sure you want to delete this note?')">Delete</button>
                            </form>
                        </div>
                    </div>
                `;
                
                postsContainer.appendChild(postDiv);
            });
        } else {
            postsContainer.innerHTML = '<p class="empty-state">You don\'t have any notes yet. <a href="/post/new">Create your first note!</a></p>';
        }
    } catch (error) {
        console.error('Error loading posts:', error);
        document.getElementById('posts-container').innerHTML = '<p class="error-state">Error loading notes. Please refresh the page.</p>';
    }
}

document.addEventListener('DOMContentLoaded', loadPosts);