function createStars(count, layer) {
    for (var i = count; i > 0; i--) {
        drawStars(layer);
    }
}

function drawStars(layer) {
    var tmpStar = document.createElement('figure');
    tmpStar.className = "star star-layer-" + layer;
    tmpStar.style.top = 100 * Math.random() + '%';
    tmpStar.style.left = 100 * Math.random() + '%';
    document.getElementById('stars').appendChild(tmpStar);
}

function selectStars() {
    stars = document.querySelectorAll(".star");
}

function animateStar(el) {
    gsap.to(el, {
        duration: Math.random() * 0.5 + 0.5,
        opacity: Math.random() * 0.8 + 0.2,
        onComplete: function() {
            animateStar(el);
        }
    });
}

function animateStars() {
    Array.prototype.forEach.call(stars, function(el, i) {
        animateStar(el);
    });
}

var stars;

createStars(200, 1);
createStars(60, 2);
createStars(40, 3);
selectStars();
animateStars();
