import puppeteer from "puppeteer";
import crypto from "crypto";

const FLAG = process.env.FLAG ?? console.log("No flag") ?? process.exit(1);

const APP_PORT = process.env.PORT || "80";
const APP_URL = `http://localhost:${APP_PORT}`;

if (!/^space{\w+}$/.test(FLAG)) {
  console.log("Bad flag");
  process.exit(1);
}

const sleep = async (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const visit = async (url) => {
  const browser = await puppeteer.launch({
    headless: "new",
    executablePath: "/usr/bin/chromium",
    args: [
      "--no-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
      '--js-flags="--noexpose_wasm"',
    ],
  });

    const context = await browser.createBrowserContext();
    const randstr = (length = 10) => {
      return crypto.randomBytes(length).toString('hex').slice(0, length);
    };


  let random_username = randstr();
  let random_password = randstr();

  try {
    const page1 = await context.newPage();

    await page1.goto(`${APP_URL}/register`);
    await page1.type('#username', random_username);
    await page1.type('#password', random_password);
    await page1.type('#confirm_password', random_password);

    await page1.click('#registerForm > button');

    await page1.waitForSelector('#loginForm > button');
    await page1.type('#username', random_username);
    await page1.type('#password', random_password);

    await page1.click('#loginForm > button');

    await page1.waitForSelector('.empty-state');
    await page1.goto(`${APP_URL}/post/new`);

    await page1.type('#title', 'The Flag');
    await page1.type('#content', `# A nice flag for you: ${FLAG}`);

    await page1.click('#newPostForm > button');
    await page1.waitForSelector('#posts-container > div > div.post-card-footer > div > a');    

    await page1.close();

    console.log(`visiting ${url}`)

    const page2 = await context.newPage();
    await page2.goto(url);
    await sleep(3_000);
    await page2.close();
  } catch (e) {
    console.error(e);
  }

  await context.close();
  await browser.close();

  console.log(`Done`);
};
