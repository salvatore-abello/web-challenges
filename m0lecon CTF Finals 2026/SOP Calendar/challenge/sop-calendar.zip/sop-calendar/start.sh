#!/bin/sh

s=$(head -c 16 /dev/urandom | base64 | tr -d '\n' | tr '+/' '-_' | tr -d '=')

echo "SECRET=${s,,}" > .env

docker compose up --build